# ECE356-lab4
Use command "python3 main.py" to run the code and get the output csv file